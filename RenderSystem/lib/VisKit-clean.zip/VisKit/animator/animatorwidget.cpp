#include "animatorwidget.h"

AnimatorWidget::AnimatorWidget(QWidget *parent) :
    QWidget(parent)
{
}
